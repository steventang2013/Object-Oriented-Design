public class testProgram{
	public static void main(String []args){
		userUtility uName = new userUtility();
		uName.createUserName("Liz","Boese");
	}
}